@extends('layouts.site')
@section('title', config('theme.name'))
@section('content')
{!!config('theme.home')!!}
@endsection
